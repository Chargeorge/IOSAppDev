
//document.getElementById AND MORE

//Hash means the ID
//document.getSelection() is the vanilla JS equivilant
//var myDiv = $("#playground");
//
////Use a seperate object for different fuctions.
//var myDivElem = document.getElementById("playground");
//
//
//myDiv.text("JQUERY  TEXT");
//
////set style
//myDiv.css("background-color", "red");
//
////Add on on click handler in jquery, equivalant to .onclick=
//$("#fader").click(
//    function(e){
//        myDiv.fadeOut(400, function(){
//            //Change text to "Different";
//          myDiv.fadeIn();
//        })
//    }
//
//);


$("#load_dog").click(function(){
    var ajax = $.ajax( "https://random.dog/woof.json");
    ajax.done(
        function(msg){
            alert("Success!" + msg.url);
            $("#doggo").attr("src", msg.url);
        }
    );
});



function getRandom3(){
    return Math.round(Math.random() * 2);
}

//$("#cat_guess").click(function(){alert(getRandom3())});

//https://ghibliapi.herokuapp.com/films


//https://aws.random.cat/meow

