
var container= document.querySelector("#container");
var root = document.createElement("table");
container.appendChild(root);



document.getElementById("MakeObject").onclick = function(e){
   
    //alert(JSON.stringify(obj));
}


//MDN look up on click event properties.  

document.getElementById("clickZone").onclick = function(e){
    //var percentage  =255 * Position in the window

}

function getRGBString(r, g, b){
    return "#"+(r).toString(16)+(g).toString(16)+(b).toString(16);
}
