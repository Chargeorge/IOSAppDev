//for(var i= 0; i< 10; i++){
//    console.log("I've gone " + i +" times");
////}
//


//var objs = ["cat", "dog", "musk ox"];
//
//for(var obj in objs){
//    console.log(obj + ": " + objs[obj]);
//}
//
//var cereals = {};
//cereals ["bland"] = "cheerios";
//cereals["chocolate"] = "count chocula";
//cereals["marhmallow"] = "lucky charms";
//
//
//var x = 0;
//while(x < 10){
//    console.log("I've gone " + x +" times");
//    x++;  
//}


//JSON

var cerealsJSON  = {
    "bland" : "cheerios",
    "chocolate" : "count chocula",
   "marshmallow" : "luckycharms"
};

console.log(cerealsJSON.chocolate);


